 tunombre=prompt("Hola.¿Como te llamas?",""),//guarda el nombre
 alert( "Bienvenido "   + tunombre + ",Encantado de conocerte")













 